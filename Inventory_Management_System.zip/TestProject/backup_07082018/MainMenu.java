import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JList;
import javax.swing.JTable;
import java.awt.Color;

public class MainMenu {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu window = new MainMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.BLACK);
		
		frame.setBounds(50, 50, 1250, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton.setBounds(1108, 21, 95, 28);
		frame.getContentPane().add(btnNewButton);
		
		JButton p_l = new JButton("Profit & Loss");
		p_l.setForeground(Color.BLACK);
		p_l.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				ProfitLoss profitloss = new ProfitLoss();
				profitloss.setVisible(true);
			}
		});
		p_l.setBounds(891, 420, 239, 53);
		frame.getContentPane().add(p_l);
		
		JButton shipping = new JButton("Shipping");
		shipping.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				shippingInfo sp = new shippingInfo();
				sp.setVisible(true);
			}
		});
		shipping.setBounds(490, 420, 234, 53);
		frame.getContentPane().add(shipping);
		
		JButton inventory = new JButton("Inventory");
		inventory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Inventory inventory = new Inventory();
				inventory.setVisible(true);
			}
		});
		inventory.setBounds(90, 420, 239, 53);
		frame.getContentPane().add(inventory);
	}
}
